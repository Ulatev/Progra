
import java.util.Arrays;
import java.util.Scanner;

//Luis Ulate 11-2

public class TareaNombres {

    public static void main(String[] args) {
        
    Scanner sc = new Scanner(System.in);
    String[] nombre = new String[20];
    for (int i = 0; i < nombre.length; i++) {
    System.out.print("ingrese el nombre de  las 20 personas(" + (i + 2) + "): ");
    nombre[i] = sc.nextLine();

    }
    Arreglo(nombre);

    String nombreM = NombreLetras(nombre);
    System.out.println("\t El nombre con mayor cantidad de letras es : " + nombreM);

    double promedio = Promedio(nombre);
    System.out.println("\t El promedio de los nombres es : " + promedio);

    int sumatoria = Sumatoria(nombre);
    System.out.println("\t La sumatoria de los nombres es : " + sumatoria);

    Impares(nombre);

    Descendente(nombre);

    Ascendente(nombre);
    }

    public static void Arreglo(String[] arreglo) { //Arreglo completo
    System.out.println("\t El contenido del arreglo es: ");
    for (int i = 0; i < arreglo.length; i++) {
    System.out.println(arreglo[i]);
    }
    }

    public static String NombreLetras(String[] arreglos) {//Nombre mas largo
    String nombreM = arreglos[0];
    for (int i = 1; i < arreglos.length; i++) {
    if (arreglos[i].length() > nombreM.length()) {
    nombreM = arreglos[i];
    }
    }
    return nombreM;
    }

    public static double Promedio(String[] arreglos) {//Promedio de los numeros
    double suma = 0;
    for (int i = 0; i < arreglos.length; i++) {
    suma += arreglos[i].length();
    }
    double promedio = suma / arreglos.length;
    return promedio;
    }

    public static int Sumatoria(String[] arreglos) {//Sumatoria de los numeros
    int sumatoria = 0;
    for (int i = 0; i < arreglos.length; i++) {
    sumatoria += arreglos[i].length();
    }
    return sumatoria;
    }

    public static void Impares(String[] arreglos) {//Muestra de numeros impares 
    System.out.println("\t Los numeros impares en el arreglo son: ");
    for (int i = 0; i < arreglos.length; i++) {
    if (i % 2 != 0) {
    System.out.println(arreglos[i]);
    }
    }
    }

    public static void Descendente(String[] arreglos) {
    Arrays.sort(arreglos);
    System.out.println("\t El orden de forma descendente es: ");
    for (int i = arreglos.length - 1; i >= 0; i--) { //Leer arreglo de manera inversa
    System.out.println(arreglos[i]);
    }
    }

    public static void Ascendente(String[] arreglos) {
    Arrays.sort(arreglos);
    System.out.println("\t El orden de forma ascendente es: ");
    for (int i = 0; i < arreglos.length; i++) { //Leer arreglo de manera ordenada
    System.out.println(arreglos[i]);
    }
    }
    }